import re
from jjcli import *

def lexer(txt):
    return re.findall(r'\w+(-\w+)*|[^\w\s]+', txt)

def main():
    cl = clfilter()
    for txt in cl.text():
        print(lexer(txt))